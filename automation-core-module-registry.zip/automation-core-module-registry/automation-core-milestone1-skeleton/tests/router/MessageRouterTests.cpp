// MessageRouter tests go here.
